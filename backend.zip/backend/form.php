<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$pdo = new PDO(
    'mysql:host=localhost;dbname=webform;charset=utf8',
    'root',
    ''
);

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data["name"] ?? "");
$phone = trim($data["phone"] ?? "");
$email = trim($data["email"] ?? "");
$comment = trim($data["comment"] ?? "");

if (!$name || !$phone || !$email) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Заполните поля"
    ]);

    exit;
}

$stmt = $pdo->prepare("
INSERT INTO applications(name, phone, email, comment)
VALUES (?, ?, ?, ?)
");

$stmt->execute([
    $name,
    $phone,
    $email,
    $comment
]);

echo json_encode([
    "success" => true,
    "message" => "Форма отправлена",
    "login" => $email,
    "password" => "test123",
    "profile" => "/profile"
]);