<?php

session_start();

$login = $_POST["login"] ?? "";
$password = $_POST["password"] ?? "";

if ($login === "admin" && $password === "123") {

    $_SESSION["auth"] = true;

    header("Location: http://localhost:3000/WebReact/");
    exit();
}

echo "Неверный логин или пароль";