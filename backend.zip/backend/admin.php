<?php

if (
    empty($_SERVER['PHP_AUTH_USER']) ||
    empty($_SERVER['PHP_AUTH_PW']) ||
    $_SERVER['PHP_AUTH_USER'] != 'admin' ||
    $_SERVER['PHP_AUTH_PW'] != 'admin'
) {
    header('HTTP/1.1 401 Unauthorized');
    header('WWW-Authenticate: Basic realm="Admin panel"');

    echo "Требуется авторизация";
    exit();
}

$pdo = new PDO(
    'mysql:host=localhost;dbname=webform;charset=utf8',
    'root',
    ''
);

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = $pdo->prepare("
        DELETE FROM applications
        WHERE id=?
    ");

    $stmt->execute([$id]);

    header("Location: admin.php");
    exit();
}




/* =========================
   UPDATE
========================= */

if (isset($_POST['update'])) {

    $id = (int) $_POST['id'];

    $stmt = $pdo->prepare("
        UPDATE applications
        SET
            name=?,
            phone=?,
            email=?,
            comment=?
        WHERE id=?
    ");

    $stmt->execute([
        $_POST['name'],
        $_POST['phone'],
        $_POST['email'],
        $_POST['comment'],
        $id
    ]);

    header("Location: admin.php");
    exit();
}




/* =========================
   GET ALL
========================= */

$stmt = $pdo->query("
    SELECT *
    FROM applications
    ORDER BY id DESC
");

$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

$edit_id = $_GET['edit'] ?? null;

?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Админка</title>

    <style>
        body {
            margin: 0;
            padding: 30px;
            background: #f5f5f5;
            font-family: Arial;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #eee;
        }

        input,
        textarea {
            width: 100%;
            box-sizing: border-box;
        }

        .btn {
            padding: 6px 10px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .edit {
            background: #ddd;
            color: black;
        }

        .delete {
            background: #ffb3b3;
            color: black;
        }

        .save {
            background: #b3ffb3;
        }
    </style>

</head>

<body>

    <div class="container">

        <h1>Админ панель</h1>

        <table>

            <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Телефон</th>
                <th>Email</th>
                <th>Комментарий</th>
                <th>Действия</th>
            </tr>

            <?php foreach ($applications as $app): ?>

                <tr>

                    <?php if ($edit_id == $app['id']): ?>

                        <form method="POST">

                            <td>
                                <?= $app['id'] ?>
                                <input type="hidden" name="id" value="<?= $app['id'] ?>">
                            </td>

                            <td>
                                <input name="name" value="<?= htmlspecialchars($app['name']) ?>">
                            </td>

                            <td>
                                <input name="phone" value="<?= htmlspecialchars($app['phone']) ?>">
                            </td>

                            <td>
                                <input name="email" value="<?= htmlspecialchars($app['email']) ?>">
                            </td>

                            <td>
                                <textarea name="comment"><?= htmlspecialchars($app['comment']) ?></textarea>
                            </td>

                            <td>
                                <button class="btn save" name="update">
                                    Сохранить
                                </button>
                            </td>

                        </form>

                    <?php else: ?>

                        <td><?= $app['id'] ?></td>

                        <td><?= htmlspecialchars($app['name']) ?></td>

                        <td><?= htmlspecialchars($app['phone']) ?></td>

                        <td><?= htmlspecialchars($app['email']) ?></td>

                        <td><?= htmlspecialchars($app['comment']) ?></td>

                        <td>

                            <a class="btn edit" href="?edit=<?= $app['id'] ?>">
                                Редактировать
                            </a>

                            <a class="btn delete" href="?delete=<?= $app['id'] ?>">
                                Удалить
                            </a>

                        </td>

                    <?php endif; ?>

                </tr>

            <?php endforeach; ?>

        </table>

    </div>

</body>

</html>